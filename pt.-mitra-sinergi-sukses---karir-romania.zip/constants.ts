
export const IMAGES = {
  hero: "https://images.unsplash.com/photo-1555992336-03a23c7b20ee?q=80&w=1920&auto=format&fit=crop",
  trust: "https://images.unsplash.com/photo-1544124499-58912cbddaad?q=80&w=800&auto=format&fit=crop",
  directorOffice: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?q=80&w=800&auto=format&fit=crop",
  viceDirector: "https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=500&auto=format&fit=crop",
  fbService: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=800&auto=format&fit=crop",
  partners: [
    "https://images.unsplash.com/photo-1552566626-52f8b828add9?q=80&w=400&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1551218808-94e220e084d2?q=80&w=400&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?q=80&w=400&auto=format&fit=crop"
  ],
  avatars: [
    "https://i.pravatar.cc/150?u=a1",
    "https://i.pravatar.cc/150?u=a2",
    "https://i.pravatar.cc/150?u=a3",
    "https://i.pravatar.cc/150?u=a4"
  ]
};

export const CONTACT_INFO = {
  wa: "62811314300",
  rani: "+62 822 7167 4145",
  victor: "+62 822 3018 4888",
  email: "info@mitragroup.id",
  hq: "Jl. Mayjen Sungkono No.77, Malang",
  marketing: "Jl. Dukuh Kupang Barat I, Surabaya"
};
