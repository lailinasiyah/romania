
import React from 'react';
import { Phone, Mail, MapPin, Clock, MessageSquare } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <div className="pt-24 pb-20">
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-extrabold text-romania-blue mb-4">Hubungi Kami</h1>
            <p className="text-xl text-slate-600">Tim kami siap membantu menjawab pertanyaan Anda seputar karir di luar negeri.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Info Cards */}
            <div className="space-y-8">
              <div className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100">
                <h3 className="text-2xl font-bold text-slate-800 mb-8">Informasi Kantor</h3>
                <div className="space-y-8">
                  <div className="flex items-start">
                    <div className="p-4 bg-blue-50 text-romania-blue rounded-2xl mr-4"><MapPin size={24} /></div>
                    <div>
                      <h4 className="font-bold text-slate-800 mb-2">Kantor Pusat Malang</h4>
                      <p className="text-slate-600">Jl. Mayjen Sungkono No.77, Bumiayu, Kec. Kedungkandang, Kota Malang, Jawa Timur</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <div className="p-4 bg-red-50 text-romania-red rounded-2xl mr-4"><MapPin size={24} /></div>
                    <div>
                      <h4 className="font-bold text-slate-800 mb-2">Kantor Marketing Surabaya</h4>
                      <p className="text-slate-600">Jl. Dukuh Kupang Barat I, Dukuh Pakis, Kota Surabaya, Jawa Timur</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100">
                <h3 className="text-2xl font-bold text-slate-800 mb-8">Informasi Kontak</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <a href="tel:6282271674145" className="flex items-center p-6 bg-slate-50 rounded-2xl border border-slate-100 hover:bg-slate-100 transition-colors">
                    <div className="p-3 bg-romania-blue text-white rounded-xl mr-4"><Phone size={20} /></div>
                    <div>
                      <p className="text-xs font-bold text-slate-400 uppercase">Rani (Recruitment)</p>
                      <p className="font-bold text-slate-800">+62 822 7167 4145</p>
                    </div>
                  </a>
                  <a href="tel:6282230184888" className="flex items-center p-6 bg-slate-50 rounded-2xl border border-slate-100 hover:bg-slate-100 transition-colors">
                    <div className="p-3 bg-romania-blue text-white rounded-xl mr-4"><Phone size={20} /></div>
                    <div>
                      <p className="text-xs font-bold text-slate-400 uppercase">Victor (Marketing)</p>
                      <p className="font-bold text-slate-800">+62 822 3018 4888</p>
                    </div>
                  </a>
                </div>
              </div>
              
              <div className="flex items-center p-6 bg-slate-900 text-white rounded-3xl shadow-xl">
                 <div className="p-4 bg-romania-yellow text-romania-blue rounded-2xl mr-6"><Clock size={28} /></div>
                 <div>
                    <h4 className="font-bold text-lg">Jam Operasional</h4>
                    <p className="text-slate-400">Senin - Jumat: 08:00 - 17:00 WIB</p>
                    <p className="text-slate-400">Sabtu: 08:00 - 13:00 WIB</p>
                 </div>
              </div>
            </div>

            {/* Quick Contact Form Placeholder */}
            <div className="bg-white p-10 rounded-3xl shadow-xl border border-slate-100">
               <h3 className="text-2xl font-bold text-slate-800 mb-8">Kirim Pesan Cepat</h3>
               <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-bold text-slate-700 mb-2">Nama Lengkap</label>
                        <input type="text" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-romania-blue" placeholder="Contoh: Budi Santoso" />
                    </div>
                    <div>
                        <label className="block text-sm font-bold text-slate-700 mb-2">Nomor WhatsApp</label>
                        <input type="text" className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-romania-blue" placeholder="0812xxxx" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Minat Karir</label>
                    <select className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-romania-blue bg-white">
                        <option>Cook / Kitchen</option>
                        <option>F&B Service / Waiter</option>
                        <option>Restaurant Management</option>
                        <option>Lainnya</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-slate-700 mb-2">Pesan Tambahan</label>
                    <textarea rows={4} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-romania-blue" placeholder="Apa yang ingin Anda tanyakan?"></textarea>
                  </div>
                  <button type="submit" className="w-full bg-romania-blue text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:bg-slate-800 transition-all flex items-center justify-center">
                    Kirim Sekarang <MessageSquare className="ml-2" size={20} />
                  </button>
               </form>
               <div className="mt-8 pt-8 border-t border-slate-100 flex items-center justify-center space-x-4 opacity-70">
                  <div className="h-px w-full bg-slate-200"></div>
                  <span className="text-xs font-bold text-slate-400 whitespace-nowrap">Official Business</span>
                  <div className="h-px w-full bg-slate-200"></div>
               </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
