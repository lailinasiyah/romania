
import React from 'react';
import { Briefcase, CheckSquare, Target, BarChart, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const JobManager: React.FC = () => {
  return (
    <div className="pt-24 pb-20">
      <section className="bg-slate-900 py-24 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl md:text-5xl font-extrabold mb-8">
                <span className="text-romania-yellow text-glow">Restaurant Manager</span> & Management
            </h1>
            <p className="text-xl text-slate-400 max-w-3xl leading-relaxed">
                Posisi kepemimpinan strategis untuk mengelola operasional bisnis kuliner di jantung benua Eropa.
            </p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="prose prose-lg text-slate-600 mb-16">
                <p className="text-xl font-medium text-slate-800 leading-relaxed mb-8">
                    Restaurant Manager bertanggung jawab mengelola operasional restoran agar berjalan efektif dan sesuai standar layanan. Posisi ini mencakup pengaturan tim, pelayanan pelanggan, serta pengawasan kualitas dan biaya operasional.
                </p>
                <h3 className="text-2xl font-bold text-slate-800 mb-6">Tanggung Jawab Utama:</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="flex space-x-4 p-6 bg-slate-50 rounded-2xl border border-slate-100">
                        <Target className="text-romania-blue shrink-0" />
                        <p>Mengawasi standar pelayanan pelanggan secara harian.</p>
                    </div>
                    <div className="flex space-x-4 p-6 bg-slate-50 rounded-2xl border border-slate-100">
                        <BarChart className="text-romania-blue shrink-0" />
                        <p>Mengelola budget, biaya operasional, dan inventory.</p>
                    </div>
                    <div className="flex space-x-4 p-6 bg-slate-50 rounded-2xl border border-slate-100">
                        <CheckSquare className="text-romania-blue shrink-0" />
                        <p>Memastikan kepatuhan terhadap regulasi kesehatan dan keselamatan kerja.</p>
                    </div>
                    <div className="flex space-x-4 p-6 bg-slate-50 rounded-2xl border border-slate-100">
                        <Briefcase className="text-romania-blue shrink-0" />
                        <p>Melatih dan mengarahkan tim staf internasional.</p>
                    </div>
                </div>
            </div>

            <div className="bg-romania-blue p-12 rounded-3xl text-white text-center">
                <h3 className="text-3xl font-bold mb-6">Siap Mengelola Restoran di Eropa?</h3>
                <p className="text-slate-300 mb-10 text-lg">Proses seleksi untuk posisi managerial membutuhkan pengalaman minimal 3-5 tahun dan kemampuan manajerial yang teruji.</p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Link to="/kontak" className="bg-romania-yellow text-romania-blue px-10 py-4 rounded-xl font-extrabold text-lg shadow-xl hover:bg-yellow-400 transition-all">
                        Ajukan Aplikasi Manager
                    </Link>
                    <Link to="/skema-biaya" className="bg-white/10 border border-white/20 px-10 py-4 rounded-xl font-bold text-lg hover:bg-white/20 transition-all">
                        Cek Biaya Program
                    </Link>
                </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default JobManager;
