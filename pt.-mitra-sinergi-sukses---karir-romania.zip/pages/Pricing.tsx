
import React from 'react';
import { ShieldCheck, Info, Ticket, Plane, CreditCard, CheckCircle2 } from 'lucide-react';

const Pricing: React.FC = () => {
  const packages = [
    {
      title: "Service Package",
      roles: "Bartender / Waiter / Cook / Floor Supervisor",
      price: "Rp 20 Juta",
      popular: true,
      highlight: "Sangat Diminati"
    },
    {
      title: "Management Package",
      roles: "Floor Manager",
      price: "Rp 25 Juta",
      popular: false
    },
    {
      title: "Head Chef Package",
      roles: "Head Chef",
      price: "Rp 30 Juta",
      popular: false
    }
  ];

  return (
    <div className="pt-24 pb-20">
      <section className="bg-slate-50 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold text-romania-blue mb-6">Skema Biaya Program Romania</h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Investasi masa depan yang terjangkau dengan transparansi pembayaran penuh di setiap tahapan proses.
          </p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
            {packages.map((pkg, i) => (
              <div key={i} className={`relative flex flex-col p-8 rounded-3xl border ${pkg.popular ? 'border-romania-blue ring-4 ring-romania-blue/5 shadow-2xl scale-105 z-10' : 'border-slate-200 shadow-xl'}`}>
                {pkg.popular && (
                  <span className="absolute -top-4 left-1/2 -translate-x-1/2 bg-romania-blue text-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
                    {pkg.highlight}
                  </span>
                )}
                <h3 className="text-xl font-bold text-slate-800 mb-2">{pkg.title}</h3>
                <p className="text-sm text-slate-500 mb-6 font-medium">{pkg.roles}</p>
                <div className="mt-auto">
                    <p className="text-slate-400 text-sm line-through">Biaya Awal</p>
                    <p className="text-4xl font-black text-romania-blue mb-8">{pkg.price}</p>
                    <a href="https://wa.me/62811314300" target="_blank" className={`block w-full text-center py-4 rounded-xl font-bold transition-all ${pkg.popular ? 'bg-romania-blue text-white hover:bg-slate-800 shadow-lg' : 'bg-slate-100 text-slate-800 hover:bg-slate-200'}`}>
                        Hubungi Untuk Detail
                    </a>
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Included */}
            <div className="bg-blue-50 p-10 rounded-3xl border border-blue-100">
              <h3 className="text-2xl font-bold text-romania-blue mb-8 flex items-center">
                <CheckCircle2 className="mr-3" /> Biaya Termasuk
              </h3>
              <ul className="space-y-4 text-slate-700">
                <li className="flex items-center"><Info size={18} className="mr-3 text-romania-blue" /> Visa & Izin Kerja Uni Eropa</li>
                <li className="flex items-center"><ShieldCheck size={18} className="mr-3 text-romania-blue" /> Asuransi Kesehatan & Kecelakaan</li>
                <li className="flex items-center"><Ticket size={18} className="mr-3 text-romania-blue" /> e-KTKLN (Tenaga Kerja Luar Negeri)</li>
                <li className="flex items-center"><CreditCard size={18} className="mr-3 text-romania-blue" /> Handling & Penanganan di Romania</li>
                <li className="flex items-center"><Plane size={18} className="mr-3 text-romania-blue" /> Tiket Pesawat Jakarta – Romania (One Way)</li>
              </ul>
            </div>

            {/* Expenses */}
            <div className="bg-slate-50 p-10 rounded-3xl border border-slate-200">
              <h3 className="text-2xl font-bold text-slate-800 mb-8 flex items-center">
                <CreditCard className="mr-3" /> Ditanggung Peserta
              </h3>
              <ul className="space-y-4 text-slate-600">
                <li className="flex items-center"><span className="w-2 h-2 bg-romania-red rounded-full mr-3"></span> Pembuatan Paspor</li>
                <li className="flex items-center"><span className="w-2 h-2 bg-romania-red rounded-full mr-3"></span> Medical Check-Up (MCU) Full</li>
                <li className="flex items-center"><span className="w-2 h-2 bg-romania-red rounded-full mr-3"></span> SKCK (Surat Keterangan Catatan Kepolisian)</li>
                <li className="flex items-center"><span className="w-2 h-2 bg-romania-red rounded-full mr-3"></span> Biaya Transport ke Kedutaan Romania di Jakarta</li>
                <li className="flex items-center"><span className="w-2 h-2 bg-romania-red rounded-full mr-3"></span> Biaya Hidup Awal (Uang Saku)</li>
              </ul>
            </div>
          </div>

          <div className="mt-20 bg-slate-900 rounded-3xl p-10 md:p-16 text-white text-center relative overflow-hidden">
             <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-romania-blue via-romania-yellow to-romania-red"></div>
             <h2 className="text-3xl font-bold mb-6">Mulai Konsultasi Gratis Sekarang</h2>
             <p className="text-slate-400 mb-10 max-w-2xl mx-auto">Konsultan kami akan menjelaskan rincian tahapan pembayaran sesuai dengan progres pengerjaan visa Anda.</p>
             <a href="https://wa.me/62811314300" target="_blank" className="inline-block bg-romania-red hover:bg-red-700 text-white px-12 py-5 rounded-2xl font-black text-xl shadow-2xl transition-all transform hover:scale-105">
                WhatsApp: +62 811 314 300
             </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Pricing;
