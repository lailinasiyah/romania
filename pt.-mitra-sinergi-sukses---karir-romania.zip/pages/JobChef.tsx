
import React from 'react';
import { Utensils, Award, DollarSign, CheckCircle, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const JobChef: React.FC = () => {
  return (
    <div className="pt-24 pb-20">
      <section className="bg-romania-blue py-24 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl md:text-5xl font-extrabold mb-8 max-w-4xl">
                Ambil Kesempatan Menjadi Seorang <span className="text-romania-yellow">Chef</span> di Rumania dengan Gaji Menjanjikan
            </h1>
            <p className="text-xl text-slate-200 max-w-3xl leading-relaxed">
                Industri kuliner di Rumania sedang berkembang pesat. Kami mencari talenta kuliner Indonesia untuk mengisi posisi-posisi kunci di restoran dan hotel mitra kami.
            </p>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 space-y-12">
              {/* Position Details */}
              <div className="prose prose-lg max-w-none text-slate-600">
                <h2 className="text-3xl font-bold text-slate-800 mb-6">Deskripsi Pekerjaan</h2>
                <p>
                  Sebagai seorang Cook atau Chef di Rumania, Anda akan bertanggung jawab untuk menyiapkan hidangan berkualitas tinggi, memastikan standar kebersihan dapur yang ketat, dan berkolaborasi dalam tim internasional. Ini adalah kesempatan langka untuk mempelajari teknik kuliner Eropa sambil memperkenalkan cita rasa global.
                </p>
                
                <h3 className="text-2xl font-bold text-slate-800 mt-10 mb-4">Posisi yang Dibutuhkan:</h3>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-4 list-none p-0">
                  <li className="flex items-center"><CheckCircle className="text-romania-blue mr-2 shrink-0" size={20} /> Junior Cook / Commis</li>
                  <li className="flex items-center"><CheckCircle className="text-romania-blue mr-2 shrink-0" size={20} /> Demi Chef de Partie</li>
                  <li className="flex items-center"><CheckCircle className="text-romania-blue mr-2 shrink-0" size={20} /> Chef de Partie (CDP)</li>
                  <li className="flex items-center"><CheckCircle className="text-romania-blue mr-2 shrink-0" size={20} /> Sous Chef</li>
                  <li className="flex items-center"><CheckCircle className="text-romania-blue mr-2 shrink-0" size={20} /> Head Chef</li>
                </ul>

                <h3 className="text-2xl font-bold text-slate-800 mt-10 mb-4">Syarat Penerimaan:</h3>
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                  <ul className="space-y-3">
                    <li>✓ Pria/Wanita Usia 20 - 45 tahun</li>
                    <li>✓ Pendidikan minimal SMA/SMK Sederajat (Perhotelan/Boga diutamakan)</li>
                    <li>✓ Memiliki pengalaman kerja di dapur (Min. 1-2 tahun)</li>
                    <li>✓ Mampu berkomunikasi dalam Bahasa Inggris dasar</li>
                    <li>✓ Sehat jasmani dan rohani, tidak memiliki riwayat penyakit menular</li>
                    <li>✓ Memiliki paspor aktif (bisa dibantu prosesnya)</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Salary Highlight Sidebar */}
            <div>
              <div className="sticky top-28 space-y-8">
                <div className="bg-romania-yellow p-8 rounded-3xl shadow-xl">
                    <div className="flex items-center mb-4">
                        <div className="p-2 bg-romania-blue rounded-lg mr-3"><DollarSign className="text-white" size={24} /></div>
                        <h3 className="text-2xl font-bold text-romania-blue">Estimasi Gaji</h3>
                    </div>
                    <div className="space-y-6">
                        <div className="border-b border-romania-blue/20 pb-4">
                            <p className="text-sm font-bold text-romania-blue/60 uppercase">Junior Cook</p>
                            <p className="text-2xl font-black text-romania-blue">RON 4,000</p>
                            <p className="text-sm font-medium">± Rp 14,8 Juta / Bulan</p>
                        </div>
                        <div className="border-b border-romania-blue/20 pb-4">
                            <p className="text-sm font-bold text-romania-blue/60 uppercase">Experienced Cook</p>
                            <p className="text-2xl font-black text-romania-blue">RON 5,000</p>
                            <p className="text-sm font-medium">± Rp 18,8 Juta / Bulan</p>
                        </div>
                        <div>
                            <p className="text-sm font-bold text-romania-blue/60 uppercase">Head Chef</p>
                            <p className="text-2xl font-black text-romania-blue">RON 8,500</p>
                            <p className="text-sm font-medium">± Rp 32 Juta / Bulan</p>
                        </div>
                    </div>
                    <p className="text-xs mt-6 italic text-romania-blue/70">* Nilai konversi dapat berubah sewaktu-waktu sesuai kurs berlaku.</p>
                </div>

                <div className="bg-slate-900 text-white p-8 rounded-3xl">
                    <h4 className="text-xl font-bold mb-4">Tertarik?</h4>
                    <p className="text-slate-400 mb-6">Segera hubungi tim kami untuk proses konsultasi dan cek biaya program.</p>
                    <Link to="/skema-biaya" className="block w-full bg-romania-red hover:bg-red-700 text-center py-4 rounded-xl font-bold transition-all shadow-lg">
                        Lihat Skema Biaya
                    </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default JobChef;
