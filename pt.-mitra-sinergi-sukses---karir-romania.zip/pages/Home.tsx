
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Utensils, Users, Briefcase, Globe, CheckCircle } from 'lucide-react';
import { IMAGES } from '../constants';

const Home: React.FC = () => {
  const featuredJobs = [
    {
      title: 'Cook',
      description: 'Peluang besar untuk bekerja di luar negeri. Kebutuhan tenaga kerja kuliner terus meningkat di berbagai negara, termasuk Rumania.',
      link: '/chef',
      icon: <Utensils className="text-white" size={24} />
    },
    {
      title: 'F&B Services',
      description: 'Profesi yang semakin diminati. Rumania membutuhkan tenaga profesional layanan makanan dan minuman untuk industri hospitality.',
      link: '/fb-service',
      icon: <Users className="text-white" size={24} />
    },
    {
      title: 'Restaurant Manager',
      description: 'Bertanggung jawab mengelola operasional agar berjalan efektif sesuai standar. Mencakup pengaturan tim dan kualitas layanan.',
      link: '/restaurant-management',
      icon: <Briefcase className="text-white" size={24} />
    }
  ];

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center overflow-hidden">
        {/* Background Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#002B7F]/90 to-transparent z-10"></div>
        <img 
          src={IMAGES.hero} 
          alt="Romania Hero" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        
        <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <div className="max-w-2xl">
            <span className="inline-block bg-[#FCD116] text-[#002B7F] font-bold px-4 py-1 rounded-full text-sm mb-6 animate-bounce">
              Kesempatan Karir Eropa 2024
            </span>
            <h1 className="text-5xl md:text-7xl font-extrabold mb-6 leading-tight">
              Membangun Karir di <span className="text-[#FCD116]">Romania</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-slate-200 font-light leading-relaxed">
              Bergabunglah bersama PT. Mitra Sinergi Sukses dan raih peluang karir internasional di sektor kuliner & hospitality. Pelatihan standar global dan lingkungan kerja dinamis menanti Anda.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/kontak" className="bg-[#CE1126] hover:bg-red-700 text-white px-8 py-4 rounded-xl font-bold text-lg flex items-center justify-center transition-all transform hover:scale-105 shadow-xl">
                Daftar Sekarang <ArrowRight className="ml-2" size={20} />
              </Link>
              <Link to="/tentang-kami" className="bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/20 text-white px-8 py-4 rounded-xl font-bold text-lg text-center transition-all">
                Pelajari Lebih Lanjut
              </Link>
            </div>
            
            <div className="mt-12 flex items-center space-x-6">
              <div className="flex -space-x-3">
                {IMAGES.avatars.map((url, i) => (
                  <img key={i} src={url} className="w-12 h-12 rounded-full border-2 border-[#002B7F]" alt="Candidate" />
                ))}
              </div>
              <p className="text-sm font-medium text-slate-300">
                <span className="text-white font-bold">500+</span> Pekerja telah kami berangkatkan
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Jobs Section */}
      <section className="py-24 bg-white relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-[#002B7F] mb-4">Bidang Kerja Unggulan</h2>
            <p className="text-slate-600 text-lg">
              Kami bekerja sama dengan berbagai grup restoran dan hotel ternama di Romania untuk memberikan penempatan terbaik bagi Anda.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredJobs.map((job) => (
              <div key={job.title} className="bg-white p-8 rounded-2xl border border-slate-100 shadow-xl hover:shadow-2xl transition-all group">
                <div className="w-14 h-14 bg-[#002B7F] rounded-xl flex items-center justify-center mb-6 group-hover:bg-[#CE1126] transition-colors">
                  {job.icon}
                </div>
                <h3 className="text-2xl font-bold mb-4 text-slate-800">{job.title}</h3>
                <p className="text-slate-600 mb-8 leading-relaxed">
                  {job.description}
                </p>
                <Link 
                  to={job.link} 
                  className="inline-flex items-center font-bold text-[#002B7F] group-hover:text-[#CE1126] transition-colors"
                >
                  Detail Peluang <ArrowRight className="ml-2" size={18} />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-20 bg-slate-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="absolute -top-10 -left-10 w-40 h-40 bg-[#FCD116]/20 rounded-full blur-3xl"></div>
              <img 
                src={IMAGES.trust} 
                alt="Hospitality Service" 
                className="rounded-3xl shadow-2xl relative z-10"
              />
              <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-2xl shadow-xl z-20 border border-slate-100">
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-green-100 rounded-full"><CheckCircle className="text-green-600" /></div>
                  <div>
                    <p className="text-2xl font-bold text-slate-800">100% Aman</p>
                    <p className="text-sm text-slate-500 text-nowrap">Izin Resmi KEMNAKER</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-[#002B7F] mb-8 leading-tight">
                Mengapa Memilih Berkarir di Romania Bersama Kami?
              </h2>
              <div className="space-y-6">
                {[
                  { title: "Gaji Kompetitif", desc: "Penghasilan menarik yang jauh di atas rata-rata nasional." },
                  { title: "Pelatihan Berstandar Global", desc: "Persiapan matang sebelum keberangkatan untuk memastikan kesuksesan Anda." },
                  { title: "Dukungan Penuh", desc: "Mulai dari pengurusan visa, asuransi, hingga penanganan di negara tujuan." }
                ].map((item, idx) => (
                  <div key={idx} className="flex space-x-4">
                    <div className="mt-1 h-6 w-6 bg-[#FCD116] rounded-full flex items-center justify-center shrink-0">
                      <span className="text-[#002B7F] text-xs font-bold">{idx + 1}</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800">{item.title}</h4>
                      <p className="text-slate-600">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-10">
                <Link to="/tentang-kami" className="text-[#002B7F] font-bold flex items-center hover:translate-x-2 transition-transform">
                  Tentang PT. Mitra Sinergi Sukses <ArrowRight className="ml-2" size={20} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Partners/Logos */}
      <section className="py-16 bg-white border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4">
          <p className="text-center text-slate-400 font-medium mb-10 tracking-widest uppercase text-sm">Mitra Terpercaya Kami</p>
          <div className="flex flex-wrap justify-center items-center gap-12 md:gap-24 opacity-60 grayscale hover:grayscale-0 transition-all">
            <div className="text-3xl font-bold text-slate-400 italic">ROMANIA FOODS</div>
            <div className="text-3xl font-bold text-slate-400 italic">EURO GASTRO</div>
            <div className="text-3xl font-bold text-slate-400 italic">BALKAN GROUP</div>
            <div className="text-3xl font-bold text-slate-400 italic">GLOBAL CHEF</div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#002B7F] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-[#FCD116]/5 skew-x-12 transform origin-top-right"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-8">Siap Mengambil Langkah Besar Anda?</h2>
          <p className="text-xl text-slate-300 mb-10 max-w-2xl mx-auto">
            Jangan lewatkan kesempatan emas ini untuk membangun masa depan karir Anda di industri kuliner internasional.
          </p>
          <Link to="/kontak" className="inline-block bg-[#FCD116] hover:bg-yellow-400 text-[#002B7F] px-10 py-4 rounded-xl font-extrabold text-xl shadow-2xl transition-all">
            Hubungi Tim Recruitment Kami
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
