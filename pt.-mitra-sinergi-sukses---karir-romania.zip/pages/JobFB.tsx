
import React from 'react';
import { GlassWater, CheckCircle, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { IMAGES } from '../constants';

const JobFB: React.FC = () => {
  return (
    <div className="pt-24 pb-20">
      <section className="bg-gradient-to-r from-blue-900 to-indigo-900 py-24 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl md:text-5xl font-extrabold mb-8">
                Karir di Bidang <span className="text-[#FCD116]">F&B Services</span>
            </h1>
            <p className="text-xl text-slate-200 max-w-3xl mx-auto leading-relaxed">
                Rumania menjadi salah satu negara yang membutuhkan tenaga profesional di bidang layanan makanan dan minuman untuk menunjang industri hospitality mereka.
            </p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div>
              <img src={IMAGES.fbService} alt="F&B Service" className="rounded-3xl shadow-2xl" />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-slate-800 mb-6">Peluang Internasional Menanti</h2>
              <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                Profesi di bidang F&B Service kini semakin diminati di pasar kerja internasional. Dengan bekerja di Rumania, Anda akan mendapatkan pengalaman melayani pelanggan dari berbagai belahan dunia, mengasah kemampuan bahasa asing, dan memahami standar pelayanan kelas dunia.
              </p>
              
              <div className="space-y-4 mb-10">
                <div className="flex items-center p-4 bg-slate-50 rounded-xl border border-slate-100">
                    <div className="p-3 bg-[#002B7F] text-white rounded-lg mr-4"><GlassWater size={24} /></div>
                    <div>
                        <h4 className="font-bold text-slate-800">Waiter / Waitress</h4>
                        <p className="text-sm text-slate-500">Memberikan pelayanan tamu yang ramah dan profesional.</p>
                    </div>
                </div>
                <div className="flex items-center p-4 bg-slate-50 rounded-xl border border-slate-100">
                    <div className="p-3 bg-[#002B7F] text-white rounded-lg mr-4"><CheckCircle size={24} /></div>
                    <div>
                        <h4 className="font-bold text-slate-800">Bartender</h4>
                        <p className="text-sm text-slate-500">Keahlian dalam pembuatan minuman dan pengelolaan bar.</p>
                    </div>
                </div>
              </div>

              <Link to="/skema-biaya" className="inline-flex items-center bg-[#CE1126] hover:bg-red-700 text-white px-8 py-4 rounded-xl font-bold transition-all shadow-xl">
                 Tertarik? Cek Harganya Sekarang <ArrowRight className="ml-2" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default JobFB;
