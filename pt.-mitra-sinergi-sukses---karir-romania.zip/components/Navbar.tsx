
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isSubmenuOpen, setIsSubmenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
    setIsSubmenuOpen(false);
    window.scrollTo(0, 0);
  }, [location]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Tentang Kami', path: '/tentang-kami' },
    { 
      name: 'Bidang Kerja', 
      path: '#', 
      submenu: [
        { name: 'Chef', path: '/chef' },
        { name: 'F&B Services', path: '/fb-service' },
        { name: 'Restaurant Manager', path: '/restaurant-management' }
      ] 
    },
    { name: 'Skema Biaya', path: '/skema-biaya' },
    { name: 'Kontak', path: '/kontak' },
  ];

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <div className="h-10 w-10 bg-romania-blue rounded flex items-center justify-center">
                <span className="text-white font-bold text-xl">M</span>
            </div>
            <div className="flex flex-col">
              <span className={`font-bold text-lg leading-tight ${isScrolled ? 'text-romania-blue' : 'text-white'}`}>PT. Mitra Sinergi Sukses</span>
              <span className={`text-xs ${isScrolled ? 'text-slate-500' : 'text-slate-200'}`}>Professional Recruitment Agency</span>
            </div>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-8 items-center">
            {navLinks.map((link) => (
              <div key={link.name} className="relative group">
                {link.submenu ? (
                  <div className="flex items-center cursor-pointer py-2">
                    <span className={`font-medium ${isScrolled ? 'text-slate-700 hover:text-romania-blue' : 'text-white hover:text-romania-yellow'} transition-colors`}>
                      {link.name}
                    </span>
                    <ChevronDown size={16} className={`ml-1 ${isScrolled ? 'text-slate-700' : 'text-white'}`} />
                    <div className="absolute top-full left-0 w-56 pt-2 hidden group-hover:block animate-fade-in">
                      <div className="bg-white rounded-lg shadow-xl py-2 border border-slate-100">
                        {link.submenu.map((sub) => (
                          <Link
                            key={sub.name}
                            to={sub.path}
                            className="block px-4 py-2 text-sm text-slate-700 hover:bg-romania-blue hover:text-white transition-colors"
                          >
                            {sub.name}
                          </Link>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <Link
                    to={link.path}
                    className={`font-medium ${isScrolled ? 'text-slate-700 hover:text-romania-blue' : 'text-white hover:text-romania-yellow'} transition-colors`}
                  >
                    {link.name}
                  </Link>
                )}
              </div>
            ))}
            <Link to="/kontak" className="bg-romania-red text-white px-6 py-2 rounded-full font-semibold hover:bg-red-700 transition-colors shadow-lg">
              Daftar Sekarang
            </Link>
          </div>

          {/* Mobile Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`${isScrolled ? 'text-romania-blue' : 'text-white'} p-2`}
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`md:hidden bg-white fixed inset-0 z-40 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="p-4 flex flex-col h-full">
            <div className="flex justify-between items-center mb-8">
                <Link to="/" className="flex items-center space-x-2">
                    <div className="h-8 w-8 bg-romania-blue rounded flex items-center justify-center">
                        <span className="text-white font-bold">M</span>
                    </div>
                    <span className="font-bold text-romania-blue">Mitra Sinergi Sukses</span>
                </Link>
                <button onClick={() => setIsOpen(false)}><X size={28} /></button>
            </div>
            <div className="flex flex-col space-y-6 text-xl">
                {navLinks.map((link) => (
                    <div key={link.name}>
                        {link.submenu ? (
                            <>
                                <button 
                                    onClick={() => setIsSubmenuOpen(!isSubmenuOpen)}
                                    className="flex items-center justify-between w-full font-medium text-slate-800"
                                >
                                    {link.name} <ChevronDown size={20} className={isSubmenuOpen ? 'rotate-180 transition-transform' : ''} />
                                </button>
                                {isSubmenuOpen && (
                                    <div className="mt-4 ml-4 flex flex-col space-y-4">
                                        {link.submenu.map((sub) => (
                                            <Link key={sub.name} to={sub.path} className="text-slate-600 text-lg">{sub.name}</Link>
                                        ))}
                                    </div>
                                )}
                            </>
                        ) : (
                            <Link to={link.path} className="font-medium text-slate-800">{link.name}</Link>
                        )}
                    </div>
                ))}
            </div>
            <div className="mt-auto pb-8">
                 <Link to="/kontak" className="block w-full bg-romania-blue text-white text-center py-4 rounded-xl font-bold shadow-lg">
                    Hubungi Kami
                </Link>
            </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
